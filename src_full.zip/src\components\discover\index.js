// client/src/components/discover/index.js
export { default as ProfileCard } from "../UserCard";
export { default as ProfileCardList } from "../UserCardList";
