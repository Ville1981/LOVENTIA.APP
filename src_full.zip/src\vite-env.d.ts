// --- REPLACE START: provide Vite environment types via reference ---
/// <reference types="vite/client" />
// --- REPLACE END ---
