// File: server/routes/billing.js
// Thin shim to keep index.js compatibility after consolidating into payment.js
export { default } from './payment.js';
