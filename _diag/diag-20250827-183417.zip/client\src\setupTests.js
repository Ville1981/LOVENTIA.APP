// client/src/setupTests.js

// Setup for React Testing Library
require("@testing-library/jest-dom");
