// --- REPLACE START: CommonJS shim for Jest and legacy require paths ---
'use strict';

// Shim file: forwards to the actual CJS model
module.exports = require('../../models/Message.cjs');
// --- REPLACE END ---
