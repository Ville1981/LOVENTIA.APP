'use strict';

// Shim: forwards to actual socket implementation
module.exports = require('../socket.js');
