// client/src/components/DiscoverFilters.jsx

// --- REPLACE START: DiscoverFilters wired for backend filters, stable options, and identical lists with ProfileForm ---
import PropTypes from "prop-types";
import React, { useMemo } from "react";
import { useTranslation } from "react-i18next";
import { useForm, FormProvider } from "react-hook-form";

// --- REPLACE START: remove unused import FormBasicInfo
// import FormBasicInfo from "./profileFields/FormBasicInfo";
// --- REPLACE END
import FormChildrenPets from "./profileFields/FormChildrenPets";
import FormEducation from "./profileFields/FormEducation";
import FormGoalSummary from "./profileFields/FormGoalSummary";
import FormLifestyle from "./profileFields/FormLifestyle";
import FormLocation from "./profileFields/FormLocation";
import FormLookingFor from "./profileFields/FormLookingFor";

/**
 * Stable option sources (kept in-code so dropdowns never "disappear" if a translation key is missing).
 * Labels are shown via t(key) || fallbackLabel, so missing keys won't blank the option.
 * These match ProfileForm exactly, including Democracy and Left/Centre/Right.
 */

// --- REPLACE START: fully-qualify i18n keys to avoid namespace mismatch and keep parity with ProfileForm ---
// Religion options (match ProfileForm)
const RELIGION_OPTIONS = [
  { value: "", key: "common:all", label: "" },
  { value: "christianity", key: "profile:religion.christianity", label: "Christianity" },
  { value: "islam", key: "profile:religion.islam", label: "Islam" },
  { value: "hinduism", key: "profile:religion.hinduism", label: "Hinduism" },
  { value: "buddhism", key: "profile:religion.buddhism", label: "Buddhism" },
  { value: "folk", key: "profile:religion.folk", label: "Folk" },
  { value: "none", key: "profile:religion.none", label: "None" },
  { value: "other", key: "profile:religion.other", label: "Other" },
  { value: "atheism", key: "profile:religion.atheism", label: "Atheism" },
];

// Religion importance options (match ProfileForm)
const RELIGION_IMPORTANCE_OPTIONS = [
  { value: "", key: "common:all", label: "" },
  { value: "Not at all important", key: "profile:religionImportance.notImportant", label: "Not at all important" },
  { value: "Somewhat important", key: "profile:religionImportance.somewhatImportant", label: "Somewhat important" },
  { value: "Very important", key: "profile:religionImportance.veryImportant", label: "Very important" },
  { value: "Essential", key: "profile:religionImportance.essential", label: "Essential" },
];

// Political ideology options (match ProfileForm with Left / Centre / Right and Democracy)
const POLITICAL_IDEOLOGY_OPTIONS = [
  { value: "", key: "common:all", label: "" },
  { value: "Left", key: "profile:options.politicalIdeology.left", label: "Left" },
  { value: "Centre", key: "profile:options.politicalIdeology.centre", label: "Centre" },
  { value: "Right", key: "profile:options.politicalIdeology.right", label: "Right" },
  { value: "Conservatism", key: "profile:options.politicalIdeology.conservatism", label: "Conservatism" },
  { value: "Liberalism", key: "profile:options.politicalIdeology.liberalism", label: "Liberalism" },
  { value: "Socialism", key: "profile:options.politicalIdeology.socialism", label: "Socialism" },
  { value: "Communism", key: "profile:options.politicalIdeology.communism", label: "Communism" },
  { value: "Fascism", key: "profile:options.politicalIdeology.fascism", label: "Fascism" },
  { value: "Environmentalism", key: "profile:options.politicalIdeology.environmentalism", label: "Environmentalism" },
  { value: "Anarchism", key: "profile:options.politicalIdeology.anarchism", label: "Anarchism" },
  { value: "Nationalism", key: "profile:options.politicalIdeology.nationalism", label: "Nationalism" },
  { value: "Populism", key: "profile:options.politicalIdeology.populism", label: "Populism" },
  { value: "Progressivism", key: "profile:options.politicalIdeology.progressivism", label: "Progressivism" },
  { value: "Libertarianism", key: "profile:options.politicalIdeology.libertarianism", label: "Libertarianism" },
  { value: "Democracy", key: "profile:options.politicalIdeology.democracy", label: "Democracy" },
  { value: "other", key: "profile:options.politicalIdeology.other", label: "Other" },
];

// Gender options (parity with ProfileForm)
const GENDER_OPTIONS = [
  { value: "", key: "common:all", label: "" },
  { value: "male", key: "profile:options.gender.male", label: "Male" },
  { value: "female", key: "profile:options.gender.female", label: "Female" },
  { value: "other", key: "profile:options.gender.other", label: "Other" },
];

// Orientation options (parity with ProfileForm)
const ORIENTATION_OPTIONS = [
  { value: "", key: "common:all", label: "" },
  { value: "straight", key: "profile:options.orientation.straight", label: "Straight" },
  { value: "gay", key: "profile:options.orientation.gay", label: "Gay" },
  { value: "bi", key: "profile:options.orientation.bisexual", label: "Bi" },
  { value: "other", key: "profile:options.orientation.other", label: "Other" },
];
// --- REPLACE END ---

/**
 * DiscoverFilters
 * Search and filter component using React Hook Form
 */
const DiscoverFilters = ({
  values,
  // --- REPLACE START: remove unused setters prop
  // setters,
  // --- REPLACE END
  handleFilter,
}) => {
  const { t /*, i18n*/ } = useTranslation(["discover", "profile", "lifestyle", "common"]);
  const methods = useForm({
    defaultValues: values,
    mode: "onSubmit",
  });
  const { handleSubmit, register } = methods;

  // Memoized mapped options
  const mappedReligionOptions = useMemo(
    () =>
      RELIGION_OPTIONS.map((opt) => ({
        ...opt,
        text: t(opt.key) || opt.label || t("common:select"),
      })),
    [t]
  );

  const mappedReligionImportanceOptions = useMemo(
    () =>
      RELIGION_IMPORTANCE_OPTIONS.map((opt) => ({
        ...opt,
        text: t(opt.key) || opt.label || t("common:select"),
      })),
    [t]
  );

  const mappedPoliticalOptions = useMemo(
    () =>
      POLITICAL_IDEOLOGY_OPTIONS.map((opt) => ({
        ...opt,
        text: t(opt.key) || opt.label || t("common:select"),
      })),
    [t]
  );

  const mappedGenderOptions = useMemo(
    () =>
      GENDER_OPTIONS.map((opt) => ({
        ...opt,
        text: t(opt.key) || opt.label || t("common:select"),
      })),
    [t]
  );

  const mappedOrientationOptions = useMemo(
    () =>
      ORIENTATION_OPTIONS.map((opt) => ({
        ...opt,
        text: t(opt.key) || opt.label || t("common:select"),
      })),
    [t]
  );

  return (
    <FormProvider {...methods}>
      <div className="w-full max-w-3xl mx-auto">
        <form
          data-cy="DiscoverFilters__form"
          onSubmit={handleSubmit(handleFilter)}
          className="flex flex-col gap-6"
        >
          {/* Title and instructions */}
          <div className="text-center">
            <h2
              data-cy="DiscoverFilters__title"
              className="text-3xl font-bold mb-2"
            >
              {t("discover:title")}
            </h2>
            <p
              data-cy="DiscoverFilters__instructions"
              className="text-gray-600"
            >
              {t("discover:instructions")}
            </p>
          </div>

          {/* Age range: minAge and maxAge */}
          <div className="flex flex-col gap-2">
            <label htmlFor="minAge" className="font-medium">
              {t("discover:ageRange")}
            </label>
            <div className="flex space-x-2">
              <input
                id="minAge"
                type="number"
                {...register("minAge")}
                min={18}
                max={120}
                className="p-2 border rounded w-1/2"
              />
              <input
                id="maxAge"
                type="number"
                {...register("maxAge")}
                min={18}
                max={120}
                className="p-2 border rounded w-1/2"
              />
            </div>
          </div>

          {/* Username (filter only) */}
          <div>
            <label className="block font-medium mb-1">
              {t("discover:username")}
            </label>
            <input
              type="text"
              {...register("username")}
              className="w-full p-2 border rounded"
            />
          </div>

          {/* Gender */}
          <div>
            <label className="block font-medium mb-1">
              {t("discover:gender.label")}
            </label>
            <select
              {...register("gender")}
              className="w-full p-2 border rounded"
            >
              {mappedGenderOptions.map((o) => (
                <option key={`${o.value || "all"}`} value={o.value}>
                  {o.text}
                </option>
              ))}
            </select>
          </div>

          {/* Sexual orientation */}
          <div>
            <label className="block font-medium mb-1">
              {t("discover:orientation.label")}
            </label>
            <select
              {...register("orientation")}
              className="w-full p-2 border rounded"
            >
              {mappedOrientationOptions.map((o) => (
                <option key={`${o.value || "all"}`} value={o.value}>
                  {o.text}
                </option>
              ))}
            </select>
          </div>

          {/* Location (country/region/city + custom) */}
          <FormLocation
            t={t}
            countryFieldName="country"
            regionFieldName="region"
            cityFieldName="city"
            customCountryFieldName="customCountry"
            customRegionFieldName="customRegion"
            customCityFieldName="customCity"
            includeAllOption
          />

          {/* Education */}
          <FormEducation t={t} includeAllOption />

          {/* Profession (placeholder select; mirror ProfileForm list when finalized) */}
          <div>
            <label className="block font-medium mb-1">
              {t("discover:profession")}
            </label>
            <select
              {...register("profession")}
              className="w-full p-2 border rounded"
            >
              <option value="">{t("common:all")}</option>
              {/* Keep in sync with ProfileForm categories if you expose them here */}
            </select>
          </div>

          {/* Religion & importance */}
          <div>
            <label className="block font-medium mb-1">
              🛐 {t("discover:religion.label")}
            </label>
            <select
              {...register("religion")}
              className="w-full p-2 border rounded"
            >
              {mappedReligionOptions.map((o) => (
                <option key={`${o.value || "all"}`} value={o.value}>
                  {o.text}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block font-medium mb-1">
              {t("discover:religionImportance")}
            </label>
            <select
              {...register("religionImportance")}
              className="w-full p-2 border rounded"
            >
              {mappedReligionImportanceOptions.map((o) => (
                <option key={`${o.value || "all"}`} value={o.value}>
                  {o.text}
                </option>
              ))}
            </select>
          </div>

          {/* Political ideology */}
          <div>
            <label className="block font-medium mb-1">
              🗳️ {t("discover:politicalIdeology")}
            </label>
            <select
              {...register("politicalIdeology")}
              className="w-full p-2 border rounded"
            >
              {mappedPoliticalOptions.map((o) => (
                <option key={`${o.value || "all"}`} value={o.value}>
                  {o.text}
                </option>
              ))}
            </select>
          </div>

          {/* Children & pets */}
          <FormChildrenPets t={t} includeAllOption />

          {/* Lifestyle (smoke/drink/drugs, etc.) */}
          <FormLifestyle t={t} includeAllOption />

          {/* Goals & summary */}
          <FormGoalSummary t={t} includeAllOption />

          {/* What are you looking for? */}
          <FormLookingFor t={t} includeAllOption />

          {/* Submit button */}
          <div className="text-center pt-3">
            <button
              data-cy="DiscoverFilters__submitButton"
              type="submit"
              className="bg-pink-600 text-white font-bold py-2 px-8 rounded-full hover:opacity-90 transition duration-200"
            >
              🔍 {t("common:filter")}
            </button>
          </div>
        </form>
      </div>
    </FormProvider>
  );
};

DiscoverFilters.propTypes = {
  values: PropTypes.object.isRequired,
  // --- REPLACE START: remove unused setters propType
  // setters: PropTypes.object.isRequired,
  // --- REPLACE END
  handleFilter: PropTypes.func.isRequired,
  // --- REPLACE START: do not require t as prop; it comes from useTranslation hook
  // t: PropTypes.func.isRequired,
  // --- REPLACE END
};

export default React.memo(DiscoverFilters);
// --- REPLACE END ---

