'use strict';

// Shim: forwards to actual message route
module.exports = require('../../routes/message.js');
