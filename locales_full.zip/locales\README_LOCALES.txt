This folder contains baseline locales for all target languages.
Currently, values for many languages are seeded from English (en) as a fallback.
You can translate key-by-key; structure is identical across languages.

Tips:
- Only change the right-hand side values; do not modify keys.
- Run your app with i18next debug to catch missing keys.
